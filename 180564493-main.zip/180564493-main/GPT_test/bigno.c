#include <stdio.h>
#include <cs50.h>

int main (void){
    int firstNo = get_int("Zadejte první číslo: ");
    int secondNo = get_int("Zadejte druhé číslo: ");
    int thirdNo = get_int("Zadejte třetí číslo: ");

    if(firstNo>=secondNo && firstNo>=thirdNo){
        printf("Největší číslo je: %i\n",firstNo);
    }
    else if(secondNo>=firstNo && secondNo>=thirdNo){
        printf("Největší číslo je: %i\n",secondNo);
    }
    else{
        printf("Největší číslo je: %i\n",thirdNo);
    }
}

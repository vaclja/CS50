#include <stdio.h>
#include <cs50.h>

int main(void){
    int cislo1, cislo2, cislo3;
    int cisla;
    int count=0;
    int cislo;

    do{
    cislo = get_int("Zadejte počet čísel - maximum 3 čísla\n");
    }while(cislo>3 || cislo<1);

    for (int i=0; i<cislo;i++){
        count++;
        cisla = get_int("Řada čísel které chci zadat jsou:\n");


    if(count==1){
        cislo1=cisla;
    }
    else if(count==2){
        cislo2=cisla;
    }
    else{
        cislo3=cisla;
    }
    }
    if(count==1){
        printf("Obraceně čísla vypíšu jako %i\n",cislo1);
    }
    else if(count==2){
        printf("Obraceně čísla vypíšu jako %i,%i\n",cislo2,cislo1);
    }
    else {
        printf("Obraceně čísla vypíšu jako %i,%i,%i\n",cislo3,cislo2,cislo1);
    }
}

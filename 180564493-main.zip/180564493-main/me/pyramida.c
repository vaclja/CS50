#include <stdio.h>
#include <cs50.h>

int main (void)
{
    int a = get_int ("Vyska pyramidy bude: ");

for (int j=0; j<a; j++) //tohle je pravda 4x
{
    for (int k=0; k<a-j-1;k++) //Tohle je pravda
    {
    printf(" ");
    }
    for (int i=0; i<=j; i++)
    {
        printf("#");
    }
    printf("\n");
}
}


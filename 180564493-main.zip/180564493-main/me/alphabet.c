#include <cs50.h>
#include <stdio.h>
#include <string.h>
int main(void)
{
    string phrase = get_string("Phrase: ");
    int lenght = strlen(phrase);
    for (int i = 0; i<lenght-1;i++)

    {
        if(phrase[i]>phrase[i+1]){
            printf("Not in order\n");
            return 0;
        }
    printf("In order - %i %i %i", phrase[0], phrase [1], phrase[2]);
    return 0;
    }
}

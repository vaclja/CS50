#include <stdio.h>
#include <cs50.h>

int valid_triangle (int a,int b,int c);
int main(void)
{
   int a = get_int("Strana a:");
   int b = get_int("Strana b:");
   int c = get_int("Strana c:");
    valid_triangle(a,b,c);
}

int valid_triangle (int a,int b,int c)
{

    if(a<=0 || b<=0 || c<=0){
        printf("Délka strany musí být větší než 0");
        return 1;
    }
    else if (a+b<c || b+c<a || c+a<b){
        printf("False\n");
        return 0;
    }
    else{
        printf("True\n");
        return 0;
    }
}


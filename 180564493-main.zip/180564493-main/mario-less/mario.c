#include <stdio.h>
#include <cs50.h>
void funkce_row (int delka, int prazdne);
int main(void)
{
int vyska;
    do{vyska = get_int("Jaká je výška pyramidy? ");
}while (vyska<1);
    for(int b = 0; b<vyska;b++)
    {
    funkce_row(b+1,vyska-(b+1));
    }
}

void funkce_row (int delka, int prazdne)
{
    for (int b=0;b<prazdne;b++)
    {
    printf(" ");
    }
    for (int a=0;a<delka;a++)
    {
        printf("#");
    }


printf("\n");
}





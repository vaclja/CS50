#include<stdio.h>
#include<cs50.h>

int main (void)
{
    int vyska = get_int ("Vyska pyramidy: ");

for (int b = 0;b<vyska;b++){

    for(int c=0;c<(vyska-b-1);c++){
        printf("1");}

    for (int i=0; i<=b;i++){
        printf("#");
    }
    printf("\n");

}
}

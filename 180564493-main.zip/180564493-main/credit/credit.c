#include<stdio.h>
#include<cs50.h>

int main(void)
{   int count;
    int sums = 0;
    int finaldigit=0;
    long creditNo;
    long creditNo1;
    long creditNo2;
    int firstdigit =0;
    int seconddigit=0;



        count = 0;
        creditNo = get_long("Number: "); //Get na číslo karty
        creditNo1=creditNo;
        creditNo2=creditNo;


    while(creditNo1>0){ //Počítač čísel
        creditNo1/=10;
        count++;
    }
    if(count<13 || count >16){
        printf("INVALID\n");
        return 0;
    }



    //checksum
    for(int i=0;creditNo!=0;i++, creditNo/=10){

        if(i%2==0){ //Sudá čísla přičtu k proměnné sums
            sums += creditNo%10;
        }
        else{
            int digit = (creditNo%10)*2; //Lichá čísla vynásobím dvěmi, pokud jsou dvoumístná, tak sečtu a přičtu k sums
            sums+= (digit%10)+(digit/10);
        }

    }
    finaldigit = sums%10; //zjistím, zda konečné číslo po vydělení je 0

    //získání prvního čísla
    while (creditNo2>=100){
       creditNo2/=10;
       firstdigit=creditNo2/10;
       seconddigit=creditNo2%10;

    }

//Zjistím o kterou z karet se jedná
    if(count == 15 && firstdigit==3 && finaldigit==0 && (seconddigit == 4 || seconddigit == 7)){
        printf("AMEX\n");
    }
    else if(count == 16 && firstdigit==5 && finaldigit==0 && (seconddigit == 1 || seconddigit == 2 || seconddigit == 3 || seconddigit == 4 || seconddigit == 5)) {
        printf("MASTERCARD\n");
    }
    else if((count == 13 || count == 16) && firstdigit==4 && finaldigit==0){
        printf("VISA\n");
    }
    else{
        printf("INVALID\n");
    }

}


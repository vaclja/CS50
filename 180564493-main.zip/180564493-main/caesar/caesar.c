#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

bool only_digit(string text);
char rotate(char p, int k);

int main(int argc, string argv[])
{
    if (argc < 2 || argc > 2 || only_digit(argv[1]) == false)
    {
        printf("Usage: ./caesar key\n");
        return 1;
    }
    // use functio to check if key is number
    only_digit(argv[1]);
    // transfer key string to int
    int k = atoi(argv[1]);

    // get input
    string plaintext = get_string("Plaintext: ");

    // rotate through each character and store it into result and print
    char result[strlen(plaintext) + 1];
    for (int i = 0, j = strlen(plaintext); i < j; i++)
    {
        result[i] = rotate(plaintext[i], k);
    }
    result[strlen(plaintext)] = '\0';

    printf("ciphertext: %s\n", result);
}
// function to test if argv[1] is a number
bool only_digit(string text)
{
    for (int i = 0, j = strlen(text); i < j; i++)
    {
        if (!isdigit(text[i]))
        {
            return false;
        }
    }
    return true;
}
// function to rotate characters by 'key' number
char rotate(char p, int k)
{
    char c;
    if (isupper(p))
    {
        c = ((k + ((int) p - 'A')) % 26) + 'A';
        return c;
    }
    else if (islower(p))
    {
        c = ((k + ((int) p - 'a')) % 26) + 'a';
        return c;
    }
    else
    {
        return p;
    }
}

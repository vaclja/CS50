#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

int count_words(string words);
int count_sentence(string words);
int count_letters(string words);

int main(void)
{
    string words = get_string("Sentence: ");
    int wordsnumber = count_words(words);
    int letternumber = count_letters(words);
    int sentencenumber = count_sentence(words);
    float L = ((float) letternumber / wordsnumber) * 100;
    float S = ((float) sentencenumber / wordsnumber) * 100;

    float index = 0.0588 * L - 0.296 * S - 15.8;
    int result = round(index);

    if (result > 1 && result < 16)
    {
        printf("Grade %i\n", result);
    }
    else if (result > 16)
    {
        printf("Grade 16+\n");
    }
    else
    {
        printf("Before Grade 1\n");
    }
}

int count_words(string words)
{
    int spaces = 1;
    for (int i = 0, j = strlen(words); i < j; i++)
    {
        if (words[i] == ' ')
        {
            spaces++;
        }
    }
    return spaces;
}

int count_letters(string words)
{
    int letters = 0;
    for (int i = 0, j = strlen(words); i < j; i++)
    {
        if (isalpha(words[i]))
        {
            letters++;
        }
    }
    return letters;
}

int count_sentence(string words)
{
    int sentences = 0;
    for (int i = 0, j = strlen(words); i < j; i++)
    {
        if (words[i] == '.' || words[i] == '!' || words[i] == '?')
        {
            sentences++;
        }
    }
    return sentences;
}

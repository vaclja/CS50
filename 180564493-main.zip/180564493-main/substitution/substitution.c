#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

bool is_string(string text);
char assign(char p, string key);

int main(int argc, string argv[])
{
    // Kontrola zda je je pouze 1 input a 26 dlouhy alphabeticky znak
    if (argc != 2 || is_string(argv[1]) == false)
    {
        printf("Usage: ./substitution key\n");
        return 1;
    }
    // Get plaintext
    string plaintext = get_string("Plaintext: ");
    // Zjištění počtu znaků v plaintext
    int k = strlen(plaintext);

    char result[k + 1];
    for (int i = 0; i < k; i++)
    {
        result[i] = assign(plaintext[i], argv[1]);
    }
    result[k] = '\0';

    printf("ciphertext: %s\n", result);
}


bool is_string(string text)
{
    // Kontrola zda je string dlouhy 26 znaku
    if (strlen(text) != 26)
    {
        return false;
    }
    // Kontrola zda je každý char v inputu alphabeticky
    for (int i = 0, j = strlen(text); i < j; i++)
    {
        if (!isalpha(text[i]))
        {
            return false;
        }
        // Kontrola každého characteru oproti všem ostatním, zda nejsou stejné
        for (int x = i + 1; x < j; x++)
        {
            if (text[i] == text[x])
            {
                return false;
            }
        }
    }

    return true;
}

char assign(char p, string key)
{
    char c;
    if (isupper(p))
    {
        int index = p - 'A';
        c = toupper(key[index]);
        return c;
    }
    else if (islower(p))
    {
        int index = p - 'a';
        c = tolower(key[index]);
        return c;
    }
    else
    {
        return c = p;
    }
}

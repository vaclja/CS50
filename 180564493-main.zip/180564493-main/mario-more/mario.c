#include <stdio.h>
#include <cs50.h>
void print_row (int bricks, int spaces);
void second_p (int hash);
int main(void)
{
    int height;
    do
    {
    height = get_int ("Výška pyramidy je: " );
    }while(height<1);
    for (int i = 0; i<height;i++)
    {
    print_row(i+1, height - (i+1));
    }

}

void print_row (int bricks, int spaces)
{
    for (int s = 0; s<spaces; s++)
    {
        printf (" ");
    }
    for (int i = 0; i < bricks; i++)
    {
        printf("#");
    }
        printf("  ");
        second_p(bricks);
        printf("\n");
}

void second_p (int hash)
{
    for(int i=0; i<hash;i++)
    {
        printf("#");
    }
}





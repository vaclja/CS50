#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>

int POINTS[] = {1, 3, 3, 2, 1, 4, 2, 4, 1, 8, 5, 1, 3, 1, 1, 3, 10, 1, 1, 1, 1, 4, 4, 8, 4, 10};

int main(void)
{

    // get player inputs
    string p1 = get_string("Player 1: ");
    string p2 = get_string("Player 2: ");

    // how long is the players input
    int lenght1 = strlen(p1);
    int lenght2 = strlen(p2);

    // inicialize arrays
    char p1char[lenght1 + 1];
    char p2char[lenght2 + 1];

    // get each char of string
    strcpy(p1char, p1);
    strcpy(p2char, p2);

    int score1 = 0;
    for (int i = 0; i < lenght1 + 1; i++)
    {
        if (isalpha(p1char[i]))
        {
            int index = toupper(p1char[i]) - 'A';
            score1 += POINTS[index];
        }
    }
    int score2 = 0;
    for (int j = 0; j < lenght2; j++)
    {
        if (isalpha(p2char[j]))
        {
            int index2 = toupper(p2char[j]) - 'A';
            score2 += POINTS[index2];
        }
    }

    if (score1 > score2)
    {
        printf("Player 1 wins!\n");
    }
    else if (score2 > score1)
    {
        printf("Player 2 wins!\n");
    }
    else
    {
        printf("Tie!\n");
    }
}
